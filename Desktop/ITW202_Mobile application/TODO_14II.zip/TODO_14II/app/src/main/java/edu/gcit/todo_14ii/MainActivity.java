package edu.gcit.todo_14ii;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



    }

    public void alertdialog(View view) {
        AlertDialog.Builder myAlertBuilder = new AlertDialog.Builder(MainActivity.this);
        myAlertBuilder.setTitle("Alert");
        myAlertBuilder.setMessage("Click OK to continue, or Cancel to stop, or pause to remain");

        myAlertBuilder.setPositiveButton("OK", (dialog, which) -> {
            Toast.makeText(getApplicationContext(), "Pressed OK", Toast.LENGTH_SHORT).show();
        });
        myAlertBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Toast.makeText(getApplicationContext(), "Pressed cancel", Toast.LENGTH_SHORT).show();
            }
        });

        myAlertBuilder.setNeutralButton("Pause", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Toast.makeText(getApplicationContext(), "Pressed pause", Toast.LENGTH_SHORT).show();
            }
        });
        myAlertBuilder.show();


    }


}

