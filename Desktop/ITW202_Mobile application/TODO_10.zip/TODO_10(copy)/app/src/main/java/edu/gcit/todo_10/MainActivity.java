package edu.gcit.todo_10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText edittxt, edittxt1;
    private TextView textView;
    public Calculator mcalculator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mcalculator = new Calculator();
        edittxt = findViewById(R.id.editText);
        edittxt1 = findViewById(R.id.editText2);
        textView = findViewById(R.id.textView);
    }

    public void DIV(View view) {
        String val1 = edittxt.getText().toString();
        String val2 = edittxt1.getText().toString();
        double result = mcalculator.div(Double.valueOf(val1),Double.valueOf(val2));
        textView.setText(String.valueOf(result));

    }

    public void MUL(View view) {
        String val1 = edittxt.getText().toString();
        String val2 = edittxt1.getText().toString();
        double result = mcalculator.mul(Double.valueOf(val1),Double.valueOf(val2));
        textView.setText(String.valueOf(result));

    }

    public void SUB(View view) {
        String val1 = edittxt.getText().toString();
        String val2 = edittxt1.getText().toString();
        double result = mcalculator.sub(Double.valueOf(val1),Double.valueOf(val2));
        textView.setText(String.valueOf(result));

    }

    public void ADD(View view) {
        String val1 = edittxt.getText().toString();
        String val2 = edittxt1.getText().toString();
        double result = mcalculator.add(Double.valueOf(val1),Double.valueOf(val2));
        textView.setText(String.valueOf(result));

    }
}