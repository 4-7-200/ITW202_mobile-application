package edu.gcit.todo_10;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */

@RunWith(JUnit4.class)
public class ExampleUnitTest {
    private Calculator mcalculate;

    @Before
    public void setUp(){
        mcalculate= new Calculator();
    }

    @Test
    public void addTwoNumber(){
        double result = mcalculate.add(1d,2d);
        assertThat(result, is(equalTo(3d)));
    }
    @Test
    public void subTwoNumber(){
        double result = mcalculate.sub(1d,2d);
        assertThat(result, is(equalTo(-1d)));
    }
    @Test
    public void subWorksWithNegativeResults(){
        double result = mcalculate.sub(-3d,-1d);
        assertThat(result, is(equalTo(-2d)));
    }
    @Test
    public void mulTwoNumber(){
        double result = mcalculate.mul(1d,2d);
        assertThat(result, is(equalTo(2d)));
    }
    @Test
    public void mulTwoNumberZero(){
        double result = mcalculate.mul(0d,2d);
        assertThat(result, is(equalTo(0d)));
    }

    @Test
    public void divTwoNumber(){
        double result = mcalculate.div(1d,2d);
        assertThat(result, is(equalTo(0.5d)));
    }
    @Test
    public void divTwoNumberZero(){
        double result = mcalculate.div(1d,0d);
        assertThat(result, is(equalTo(Double.POSITIVE_INFINITY)));
    }






}