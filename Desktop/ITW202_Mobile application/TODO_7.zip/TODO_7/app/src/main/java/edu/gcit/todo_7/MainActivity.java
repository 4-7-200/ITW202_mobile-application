package edu.gcit.todo_7;


import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    private int dawa=0;
    private TextView tx;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tx = (TextView) findViewById(R.id.tx);
        if(savedInstanceState != null){
            dawa = savedInstanceState.getInt("Count");
            tx.setText(String.valueOf(dawa));
        }

    }

    public void dawa(View view) {
        dawa++;
        tx.setText(String.valueOf(dawa));
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("Count",dawa);
    }
}
