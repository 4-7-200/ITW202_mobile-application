package edu.gcit.todo_25;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText firstName, lastName, ITW101, Enroll;

    private Button Add,View,Update,Delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firstName = findViewById(R.id.FirstName);
        lastName = findViewById(R.id.LastName);
        ITW101 = findViewById(R.id.ITW101);
        Enroll = findViewById(R.id.StudentNo);

        Add = findViewById(R.id.bt1);
        View = findViewById(R.id.bt2);
        Update = findViewById(R.id.bt3);
        Delete = findViewById(R.id.bt4);

        //linking main activity with DatabaseHelper class
        DatabaseHelper myDB = new DatabaseHelper(this);

        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                boolean isInserted = myDB.insertData(Enroll.getText().toString(),
                        firstName.getText().toString(),
                        lastName.getText().toString(),
                        ITW101.getText().toString());

                if (isInserted == true) {
                    Toast.makeText(getApplicationContext(), "Data Inserted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Data Not Inserted", Toast.LENGTH_SHORT).show();
                }

            }
        });
        View.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                //data formate in cursor

                Cursor cursor=myDB.getAllDate();
                if(cursor.getCount()==0){
                    showMessage("Error", "Nothing Found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(cursor.moveToNext()){
                    buffer.append("Enroll:" + cursor.getString(0)+"\n");
                    buffer.append("First Name:" + cursor.getString(1)+"\n");
                    buffer.append("Last Name:" + cursor.getString(2)+"\n");
                    buffer.append("Marks:" + cursor.getString(3)+"\n");
                }
                //shows all the data
                showMessage("List Of Students",buffer.toString());
            }
        });
        Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                boolean isUpdate = myDB.updateData(Enroll.getText().toString(),
                        firstName.getText().toString(),
                        lastName.getText().toString(),
                        ITW101.getText().toString());

                if (isUpdate == true) {
                    Toast.makeText(getApplicationContext(), "Data is update", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Data Not Update", Toast.LENGTH_SHORT).show();
                }

            }
        });
        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                Integer deleteRow= myDB.deleteData(Enroll.getText().toString());
                if(deleteRow > 0){
                    Toast.makeText(getApplicationContext(), "Data is Deleted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Data Not Deleted", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showMessage(String title, String message) {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();

    }

}