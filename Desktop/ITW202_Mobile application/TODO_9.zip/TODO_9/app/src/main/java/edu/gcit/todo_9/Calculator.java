package edu.gcit.todo_9;

public class Calculator {
    public double add(double value1,double value2){
        return value1 + value2;
    }
    public double sub(double value1,double value2){
        return value1 - value2;
    }
    public double mul(double value1,double value2){
        return value1 * value2;
    }
    public double div(double value1,double value2){
        return value1 / value2;
    }
}
